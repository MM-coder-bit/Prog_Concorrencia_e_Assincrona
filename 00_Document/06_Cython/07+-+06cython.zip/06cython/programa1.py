import cumprimenta

def main():
    nome: str = input('Qual o seu nome? ')
    cumprimenta.cumprimentar(nome)



if __name__ == '__main__':
    main()
